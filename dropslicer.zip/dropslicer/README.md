 ### Install

```
npm install
```


 ### Run Local Development
```
pbiviz upgrade
pbiviz start
```

### Package Dist 
```
pbiviz package 
```